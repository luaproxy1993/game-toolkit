# B · 场景轨

静帧生成跟 `game-asset-core`。动起来跟 `game-animation-frames`（video-first）。数字人背景 still plate 跟 `pixverse-r1` `SEED_VIDEO.md`。

## B1 场景静帧

- 原生画幅：场景板是场景板，地图是地图，禁止把 1:1 油画塞进 16:9 槽。  
- 与立绘同一主外观（光、色、介质）。  
- 完成：硬刷新后进房看到的就是这张；旅行缩略图另出，不拿地图冒充。

## B2 idle loop

- 从 B1 静帧 i2v：机位锁、微动（旗、烛、雾、布），首尾可接。  
- 主体清单写进 prompt（棺、门、祭坛），验收时逐项还在。  
- 创建页背景轮播只用**房间静帧**，3s 交叉淡入淡出；opt-in；不碰 CharacterActor。  
- 完成：loop 两圈无跳；关视频时静帧仍是那张。
